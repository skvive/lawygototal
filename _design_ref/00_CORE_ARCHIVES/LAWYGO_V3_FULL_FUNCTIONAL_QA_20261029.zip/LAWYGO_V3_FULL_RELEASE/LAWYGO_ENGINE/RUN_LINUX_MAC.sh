#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ! -f .venv/bin/python ]]; then python3 -m venv .venv; fi
.venv/bin/python -m pip install -r requirements.txt
[[ -f .env ]] || cp .env.example .env
.venv/bin/python setup_admin.py
.venv/bin/python app.py
